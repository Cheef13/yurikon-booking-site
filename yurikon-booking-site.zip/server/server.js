import express from 'express';
import path from 'path';
import cors from 'cors';
import { fileURLToPath } from 'url';
import { nanoid } from 'nanoid';
import db from './db.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json());
app.use(cors());

// ---------- DB helpers ----------
const getLawyers = () => db.prepare('SELECT * FROM lawyers').all();
const getLawyerById = (id) => db.prepare('SELECT * FROM lawyers WHERE id = ?').get(id);
const getReviewsByLawyer = (lawyerId) => db.prepare('SELECT * FROM reviews WHERE lawyer_id = ? ORDER BY created_at DESC').all(lawyerId);

const getBooking = (id) => db.prepare('SELECT * FROM bookings WHERE id = ?').get(id);
const insertBooking = (b) => db.prepare(`INSERT INTO bookings
  (id,lawyer_id,client_name,client_phone,services_json,start_iso,end_iso,address,lat,lng,confirmed,created_at)
  VALUES(@id,@lawyer_id,@client_name,@client_phone,@services_json,@start_iso,@end_iso,@address,@lat,@lng,@confirmed,@created_at)
`).run(b);
const confirmBooking = (id) => db.prepare('UPDATE bookings SET confirmed = 1 WHERE id = ?').run(id);

// ---------- API ----------
app.get('/api/health', (req,res)=> res.json({ ok: true }));

app.get('/api/lawyers', (req,res)=>{
  res.json(getLawyers());
});

app.get('/api/lawyers/:id', (req,res)=>{
  const l = getLawyerById(req.params.id);
  if(!l) return res.status(404).json({ error: 'Lawyer not found' });
  const reviews = getReviewsByLawyer(l.id);
  res.json({ ...l, reviews });
});

app.post('/api/bookings', (req,res)=>{
  try{
    const { lawyerId, clientName, clientPhone, services, startISO, endISO, address, lat, lng } = req.body;
    const id = nanoid(8);
    const payload = {
      id,
      lawyer_id: lawyerId,
      client_name: clientName,
      client_phone: clientPhone || null,
      services_json: JSON.stringify(services || []),
      start_iso: startISO,
      end_iso: endISO,
      address: address || null,
      lat: lat ?? null,
      lng: lng ?? null,
      confirmed: 0,
      created_at: new Date().toISOString()
    };
    insertBooking(payload);
    res.json({ id, link: `/b/${id}` });
  }catch(e){
    console.error(e);
    res.status(400).json({ error: 'Failed to create booking' });
  }
});

app.get('/api/bookings/:id', (req,res)=>{
  const b = getBooking(req.params.id);
  if(!b) return res.status(404).json({ error: 'Booking not found' });
  const lawyer = getLawyerById(b.lawyer_id);
  const reviews = getReviewsByLawyer(b.lawyer_id);
  res.json({
    booking: {
      id: b.id,
      clientName: b.client_name,
      clientPhone: b.client_phone,
      services: JSON.parse(b.services_json || '[]'),
      startISO: b.start_iso,
      endISO: b.end_iso,
      address: b.address || lawyer.address,
      lat: b.lat ?? lawyer.lat,
      lng: b.lng ?? lawyer.lng,
      confirmed: !!b.confirmed
    },
    lawyer,
    reviews
  });
});

app.post('/api/bookings/:id/confirm', (req,res)=>{
  const b = getBooking(req.params.id);
  if(!b) return res.status(404).json({ error: 'Booking not found' });
  confirmBooking(req.params.id);
  res.json({ ok: true });
});

// ---------- Static (client) ----------
const clientDist = path.resolve(__dirname, '../client/dist');
app.use(express.static(clientDist));

// History fallback for SPA routes
app.get('*', (req,res)=>{
  res.sendFile(path.join(clientDist, 'index.html'));
});

const PORT = process.env.PORT || 8080;
// Note: vite preview will serve on 5173 in dev; here we serve built files on 8080
app.listen(PORT, ()=> {
  console.log(`Server listening on http://localhost:${PORT}`);
});
