import fs from 'fs';
import path from 'path';
import { nanoid } from 'nanoid';
import db from './db.js';

const schema = fs.readFileSync(path.resolve('./schema.sql'), 'utf-8');
db.exec(schema);

// Helpers
const run = (sql, params=[]) => db.prepare(sql).run(params);
const insertLawyer = (l) => run(
  `INSERT INTO lawyers(id,name,title,rating,reviews_count,phone,website,address,lat,lng,photo_url)
   VALUES(@id,@name,@title,@rating,@reviews_count,@phone,@website,@address,@lat,@lng,@photo_url)`, l);

const insertReview = (r) => run(
  `INSERT INTO reviews(id,lawyer_id,author,rating,text,created_at)
   VALUES(@id,@lawyer_id,@author,@rating,@text,@created_at)`, r);

// Wipe
run('DELETE FROM reviews');
run('DELETE FROM bookings');
run('DELETE FROM lawyers');

const lawyers = [
  {
    id: 'aslan',
    name: 'Аслан',
    title: 'Руководитель «ЮриКон», юрист по гражданским делам',
    rating: 4.9,
    reviews_count: 221,
    phone: '+7 (900) 000‑00‑01',
    website: 'https://example.com',
    address: 'Майкоп, ул. Краснооктябрьская, 10',
    lat: 44.607, lng: 40.105, // пример координат Майкопа
    photo_url: '/images/aslan.jpg'
  },
  {
    id: 'zuriat',
    name: 'Зурият',
    title: 'Консультант, семейные и потребительские споры',
    rating: 4.8,
    reviews_count: 134,
    phone: '+7 (900) 000‑00‑02',
    website: 'https://example.com',
    address: 'Майкоп, ул. Краснооктябрьская, 10',
    lat: 44.607, lng: 40.105,
    photo_url: '/images/zuriat.jpg'
  },
  {
    id: 'hazret',
    name: 'Хазрет',
    title: 'Исполнитель, земельные и кадастровые вопросы',
    rating: 4.7,
    reviews_count: 98,
    phone: '+7 (900) 000‑00‑03',
    website: 'https://example.com',
    address: 'Майкоп, ул. Краснооктябрьская, 10',
    lat: 44.607, lng: 40.105,
    photo_url: '/images/hazret.jpg'
  }
];

lawyers.forEach(insertLawyer);

const sampleReviews = [
  { lawyer_id: 'aslan', author: 'Алина', rating: 5, text: 'Оперативно и по делу. Вернули деньги за некачественный товар.', created_at: new Date().toISOString() },
  { lawyer_id: 'aslan', author: 'Руслан', rating: 5, text: 'Подготовили иск по земельному спору, выиграли дело.', created_at: new Date().toISOString() },
  { lawyer_id: 'zuriat', author: 'Марина', rating: 5, text: 'Тонко разобралась с алиментами и кредитами, спасибо!', created_at: new Date().toISOString() },
  { lawyer_id: 'hazret', author: 'Олег', rating: 4, text: 'Сложный вопрос по межеванию — все объяснил и сделал.', created_at: new Date().toISOString() },
];

sampleReviews.forEach(r => insertReview({ id: nanoid(10), ...r }));

console.log('Seed completed. Lawyers:', lawyers.length, 'Reviews:', sampleReviews.length);
