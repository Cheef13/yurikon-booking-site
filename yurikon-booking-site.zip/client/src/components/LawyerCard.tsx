import { Lawyer, Review, Service } from '../types'

type Props = {
  lawyer: Lawyer,
  when: { startISO: string, endISO: string },
  services: Service[],
  address?: string,
  confirmed?: boolean
  onConfirm?: ()=>void
}

function formatDT(iso:string){
  const date = new Date(iso)
  const formatter = new Intl.DateTimeFormat('ru-RU', { day:'numeric', month:'long' })
  const timeFmt = new Intl.DateTimeFormat('ru-RU', { hour:'2-digit', minute:'2-digit' })
  return {
    date: formatter.format(date),
    time: timeFmt.format(date)
  }
}

function sum(services:Service[]){
  return services.reduce((acc,s)=> acc + (s.price||0), 0)
}

export default function LawyerCard({ lawyer, when, services, address, confirmed, onConfirm }:Props){
  const start = formatDT(when.startISO)
  const end = formatDT(when.endISO)

  return (
    <div className="card">
      <div className="row">
        <div className="avatar"><img src={lawyer.photo_url || '/images/avatar.png'} alt={lawyer.name}/></div>
        <div className="col" style={{gap:4}}>
          <h1>{lawyer.name}</h1>
          <div className="small">{lawyer.title}</div>
          <div className="row" style={{gap:8}}>
            <span className="badge">★ {lawyer.rating.toFixed(1)}</span>
            <span className="pill">{lawyer.reviews_count} отзывов</span>
          </div>
        </div>
        <div style={{marginLeft:'auto', display:'flex', flexDirection:'column', gap:8, alignItems:'flex-end'}}>
          <div className="time-badge">{start.date}, {start.time} — {end.time}</div>
          <div className={'status ' + (confirmed ? 'ok' : '')}>
            {confirmed ? 'Запись подтверждена' : 'Ожидает подтверждения'}
          </div>
        </div>
      </div>

      <div className="grid" style={{marginTop:16}}>
        <section className="section">
          <h2>Услуги</h2>
          <div className="list">
            {services.map((s,i)=>(
              <div className="service" key={i}>
                <div>{s.title}</div>
                <b>{s.price.toLocaleString('ru-RU')} ₽</b>
              </div>
            ))}
            <div className="total">
              <div className="small">Итого</div>
              <b>{sum(services).toLocaleString('ru-RU')} ₽</b>
            </div>
          </div>

          {!confirmed && onConfirm && (
            <button className="btn ok" onClick={onConfirm}>Подтвердить запись</button>
          )}
        </section>

        <aside className="section">
          <h2>Адрес и контакты</h2>
          <div className="item">
            <div className="icon">☎</div>
            <div>
              <div className="kv"><b>Телефон</b></div>
              <div><a className="link" href={`tel:${lawyer.phone || ''}`}>{lawyer.phone || '—'}</a></div>
            </div>
          </div>
          <div className="item">
            <div className="icon">🌐</div>
            <div>
              <div className="kv"><b>Сайт</b></div>
              <div><a className="link" href={lawyer.website || '#'} target="_blank">{lawyer.website || '—'}</a></div>
            </div>
          </div>
          <div className="item">
            <div className="icon">📍</div>
            <div>
              <div className="kv"><b>Адрес</b></div>
              <div>{address || lawyer.address || '—'}</div>
            </div>
          </div>
          <div id="map" className="map"></div>
        </aside>
      </div>
    </div>
  )
}
