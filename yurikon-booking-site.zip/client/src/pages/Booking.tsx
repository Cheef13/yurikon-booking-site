import { useEffect, useRef, useState } from 'react'
import { useParams } from 'react-router-dom'
import LawyerCard from '../components/LawyerCard'
import { BookingResponse } from '../types'

export default function BookingPage(){
  const { id } = useParams()
  const [data, setData] = useState<BookingResponse | null>(null)
  const [loading, setLoading] = useState(true)
  const mapRef = useRef<any>(null)

  useEffect(()=>{
    async function load(){
      try{
        const res = await fetch('/api/bookings/' + id)
        const json = await res.json()
        setData(json)
      }finally{
        setLoading(false)
      }
    }
    load()
  },[id])

  useEffect(()=>{
    // Init Leaflet map when data is ready
    if(!data) return
    const L = (window as any).L
    if(!L) return

    const lat = data.booking.lat ?? data.lawyer.lat
    const lng = data.booking.lng ?? data.lawyer.lng
    if(lat==null || lng==null) return

    if(mapRef.current){
      mapRef.current.remove()
    }
    mapRef.current = L.map('map').setView([lat, lng], 16)
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19
    }).addTo(mapRef.current)
    L.marker([lat,lng]).addTo(mapRef.current)
  },[data])

  async function confirm(){
    const res = await fetch('/api/bookings/' + id + '/confirm', { method:'POST' })
    if(res.ok){
      setData(prev => prev ? { ...prev, booking: { ...prev.booking, confirmed:true } } : prev)
    }else{
      alert('Не удалось подтвердить запись')
    }
  }

  if(loading) return <div className="card">Загрузка…</div>
  if(!data) return <div className="card">Запись не найдена</div>

  const { booking, lawyer } = data

  return (
    <div className="grid">
      <div className="section" style={{gridColumn:'1 / -1'}}>
        <LawyerCard
          lawyer={lawyer}
          when={{ startISO: booking.startISO, endISO: booking.endISO }}
          services={booking.services}
          address={booking.address || lawyer.address}
          confirmed={booking.confirmed}
          onConfirm={booking.confirmed ? undefined : confirm}
        />
      </div>

      <div className="card" style={{gridColumn:'1 / -1'}}>
        <h2>Отзывы ({data.reviews.length})</h2>
        <div className="list">
          {data.reviews.map(r=>(
            <div className="item" key={r.id}>
              <div className="icon">★</div>
              <div>
                <div className="kv"><b>{r.author}</b> <span className="dot">•</span> {r.rating} / 5</div>
                <div>{r.text}</div>
                <div className="small">{new Date(r.created_at).toLocaleDateString('ru-RU')}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  )
}
