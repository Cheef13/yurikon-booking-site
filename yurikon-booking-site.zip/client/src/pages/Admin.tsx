import { useEffect, useMemo, useState } from 'react'
import { Lawyer, Service } from '../types'

type NewBookingForm = {
  lawyerId: string
  clientName: string
  clientPhone?: string
  servicesText: string
  startISO: string
  endISO: string
  address?: string
  lat?: string
  lng?: string
}

export default function Admin(){
  const [lawyers, setLawyers] = useState<Lawyer[]>([])
  const [form, setForm] = useState<NewBookingForm>({
    lawyerId:'',
    clientName:'',
    clientPhone:'',
    servicesText:'Консультация юриста — 2000',
    startISO: new Date(Date.now()+60*60*1000).toISOString().slice(0,16),
    endISO: new Date(Date.now()+2*60*60*1000).toISOString().slice(0,16),
    address:'',
    lat:'',
    lng:''
  })
  const [link, setLink] = useState<string>('')

  useEffect(()=>{
    fetch('/api/lawyers').then(r=>r.json()).then(setLawyers)
  },[])

  const services:Service[] = useMemo(()=>{
    return form.servicesText.split('\n').map(line=>{
      const [title, priceRaw] = line.split('—')
      const price = parseInt((priceRaw||'').replace(/\D/g,'')||'0',10)
      return { title: (title||'').trim(), price: isNaN(price) ? 0 : price }
    }).filter(s=>s.title)
  },[form.servicesText])

  async function createLink(){
    const payload = {
      lawyerId: form.lawyerId || (lawyers[0]?.id || ''),
      clientName: form.clientName,
      clientPhone: form.clientPhone,
      services,
      startISO: new Date(form.startISO).toISOString(),
      endISO: new Date(form.endISO).toISOString(),
      address: form.address || undefined,
      lat: form.lat ? Number(form.lat) : undefined,
      lng: form.lng ? Number(form.lng) : undefined
    }
    const res = await fetch('/api/bookings', {
      method: 'POST',
      headers: { 'Content-Type':'application/json' },
      body: JSON.stringify(payload)
    })
    const data = await res.json()
    if(data.id){
      const absolute = `${location.origin}/b/${data.id}`
      setLink(absolute)
      try{
        await navigator.clipboard.writeText(absolute)
      }catch{}
    }else{
      alert('Не удалось создать ссылку')
    }
  }

  return (
    <div className="grid" style={{gap:16}}>
      <div className="card">
        <h1>Создать персональную ссылку</h1>
        <p className="small">После звонка заполните форму и отправьте ссылку клиенту. Список юристов берётся из базы.</p>
        <div className="form-row">
          <label>Юрист</label>
          <select value={form.lawyerId} onChange={e=>setForm({...form, lawyerId:e.target.value})}>
            <option value="" disabled>Выберите юриста</option>
            {lawyers.map(l=><option key={l.id} value={l.id}>{l.name} — {l.title}</option>)}
          </select>
        </div>
        <div className="form-row form-2">
          <div>
            <label>Клиент</label>
            <input value={form.clientName} onChange={e=>setForm({...form, clientName:e.target.value})} placeholder="ФИО клиента"/>
          </div>
          <div>
            <label>Телефон клиента</label>
            <input value={form.clientPhone} onChange={e=>setForm({...form, clientPhone:e.target.value})} placeholder="+7 ..."/>
          </div>
        </div>
        <div className="form-row">
          <label>Услуги (по строке, формат: «Название — 2000»)</label>
          <textarea rows={4} value={form.servicesText} onChange={e=>setForm({...form, servicesText:e.target.value})}/>
          <div className="small">Будет отображаться список и «Итого».</div>
        </div>
        <div className="form-row form-3">
          <div>
            <label>Начало</label>
            <input type="datetime-local" value={form.startISO} onChange={e=>setForm({...form, startISO:e.target.value})}/>
          </div>
          <div>
            <label>Окончание</label>
            <input type="datetime-local" value={form.endISO} onChange={e=>setForm({...form, endISO:e.target.value})}/>
          </div>
          <div>
            <label>Адрес (необязательно)</label>
            <input value={form.address} onChange={e=>setForm({...form, address:e.target.value})} placeholder="Если пусто — возьмём из карточки юриста"/>
          </div>
        </div>
        <div className="form-row form-2">
          <div>
            <label>Широта (lat)</label>
            <input value={form.lat} onChange={e=>setForm({...form, lat:e.target.value})} placeholder="Напр. 44.607"/>
          </div>
          <div>
            <label>Долгота (lng)</label>
            <input value={form.lng} onChange={e=>setForm({...form, lng:e.target.value})} placeholder="Напр. 40.105"/>
          </div>
        </div>
        <button className="btn" onClick={createLink}>Создать ссылку</button>
        {link && (
          <div style={{marginTop:12}}>
            <div className="kv"><b>Ссылка готова:</b></div>
            <div><a className="link" href={link} target="_blank">{link}</a></div>
            <div className="small">Мы скопировали её в буфер обмена (если браузер разрешил).</div>
          </div>
        )}
      </div>

      <div className="card">
        <h2>Предпросмотр услуг</h2>
        <ul className="list">
          {services.map((s,i)=>(
            <li key={i} className="service">
              <span>{s.title}</span>
              <b>{s.price.toLocaleString('ru-RU')} ₽</b>
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}
