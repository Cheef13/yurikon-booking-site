import { Outlet, Link } from 'react-router-dom'

export default function App(){
  return (
    <div>
      <div className="container">
        <header style={{display:'flex', gap:12, alignItems:'center', margin:'10px 0 16px'}}>
          <div className="avatar" style={{width:40,height:40,borderRadius:8}}>
            <img src="/logo.svg" alt="ЮриКон"/>
          </div>
          <div style={{display:'flex',flexDirection:'column',lineHeight:1}}>
            <b>ЮриКон</b>
            <span className="small">Запись и подтверждение</span>
          </div>
          <div style={{marginLeft:'auto'}} className="small">
            <a className="link" href="/">Создать ссылку</a>
          </div>
        </header>
        <Outlet />
        <footer className="footer">
          © {new Date().getFullYear()} ЮриКон
        </footer>
      </div>
    </div>
  )
}
