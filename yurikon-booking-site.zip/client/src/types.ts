export type Lawyer = {
  id: string;
  name: string;
  title: string;
  rating: number;
  reviews_count: number;
  phone?: string;
  website?: string;
  address?: string;
  lat?: number;
  lng?: number;
  photo_url?: string;
}

export type Review = {
  id: string;
  lawyer_id: string;
  author: string;
  rating: number;
  text: string;
  created_at: string;
}

export type Service = {
  title: string;
  price: number;
}

export type Booking = {
  id: string;
  lawyerId: string;
  clientName: string;
  clientPhone?: string;
  services: Service[];
  startISO: string;
  endISO: string;
  address?: string;
  lat?: number;
  lng?: number;
  confirmed: boolean;
}

export type BookingResponse = {
  booking: {
    id: string;
    clientName: string;
    clientPhone?: string;
    services: Service[];
    startISO: string;
    endISO: string;
    address?: string;
    lat?: number;
    lng?: number;
    confirmed: boolean;
  };
  lawyer: Lawyer;
  reviews: Review[];
}
